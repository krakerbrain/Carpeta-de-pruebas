Desafío - Operaciones en una tabla

Integrantes:

- Francisco Cataldo
- Alejandra Cristi
- Williams Hernandez
- Mario Montenegro
